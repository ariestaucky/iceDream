import React from "react";

const Loading_Two = () => {
    return (
        <div className="row">
            <div className="col-lg-4 col-sm-6 portfolio-item">
                <div className="linear-background"></div>
            </div>
            <div className="col-lg-4 col-sm-6 portfolio-item">
                <div className="linear-background"></div>
            </div>
            <div className="col-lg-4 col-sm-6 portfolio-item">
                <div className="linear-background"></div>
            </div>
            <div className="col-lg-4 col-sm-6 portfolio-item">
                <div className="linear-background"></div>
            </div>
            <div className="col-lg-4 col-sm-6 portfolio-item">
                <div className="linear-background"></div>
            </div>
            <div className="col-lg-4 col-sm-6 portfolio-item">
                <div className="linear-background"></div>
            </div>
        </div>
    );
};

export default Loading_Two;
